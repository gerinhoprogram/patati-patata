
<div class="topo">
	<div id="topo">
        <div class="logo">
            <img src="core/imagens/logo.png" alt="Cahe" title="Cahe">
        </div>
        <div class="menu">
            <?php include ('core/mod_menu/menu.php')?>
        </div>
    </div>
</div>

<div class='banner-topo'>
    <div class='linha'>
        <div class="colunas lg-12 md-12 pq-12 logo">
            <img src="core/imagens/logo-patati.png" alt="Cahe - Produtos" title='Cahe - Produtos' class="wow bounceIn">
            <iframe src="https://www.youtube.com/embed/WpDUrCGaDQ0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
</div>