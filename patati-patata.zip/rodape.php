<div class='linha' style='padding-top: 50px; padding-bottom: 30px'>
    <div class="colunas lg-3 md-6 pq-12" style="height: 120px">
        Siga-nos<br>nas redes sociais
        <div class="linha">
            <div class="colunas lg-3 md-3 pq-3"><span class='vazio'>&nbsp;</span></div>
            <div class='colunas lg-2 md-2 pq-2' style='padding: 0px'>
                <a href="https://www.youtube.com/channel/UCrpC5H__88vwnD-dUT9IYVQ/featured" target="_blank" rel="noopener" title="YouTube">
                    <div class='redes'>
                        <i class="fa fa-youtube-play" aria-hidden="true"></i>
                    </div>
                </a>
            </div>
            <div class='colunas lg-2 md-2 pq-2' style='padding: 0px'>
                <a href="https://www.facebook.com/cahefraldas" target="_blank" rel="noopener" title="Facebook Cahe Produtos">
                    <div class='redes'>
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                    </div>
                </a>
            </div>
            <div class='colunas lg-2 md-2 pq-2' style='padding: 0px'>
                <a href="https://www.instagram.com/cahefraldas/" target="_blank" rel="noopener" title="Instagram Cahe Produtos">
                    <div class='redes'>
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                    </div>
                </a>
            </div>
            <div class="colunas lg-3 md-3 pq-3"><span class='vazio'>&nbsp;</span></div>
        </div>
    </div>
    <div class="colunas lg-3 md-6 pq-12 site" style="height: 120px">
        <a href="https://www.lojacahe.com.br/" target="_blanck" rel="noopener" title="Loja Cahe">
            <p>lojacahe.com.br</p>
        </a>
    </div>
    <div class="colunas lg-3 md-6 pq-12 logo-rodape" style="height: 120px"><img src="core/imagens/logo-patati.png" alt="Patai Patatá" title="Patai Patatá"></div>
    <div class="colunas lg-3 md-6 pq-12 logo-cahe" style="height: 120px">
        <a href="http://www.caheprodutos.com.br/" target="_parrent"><img src="core/imagens/logo.png" alt="Cahe Produtos" title="Cahe Produtos"></a>
    </div>
</div>